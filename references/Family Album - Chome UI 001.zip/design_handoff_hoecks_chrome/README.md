# Handoff: The Hoecks — UI Chrome Glow-Up

## Overview
A visual + interaction-polish redesign of the **chrome** (navigation, settings, upload) for *The Hoecks*, a private family photo album — a mobile-first PWA installed to the iOS Home Screen (standalone). The goal is an intimate, warm, quietly premium "keepsake archive" feel — the photos are the star; the chrome recedes. This package covers three target components plus one new feature (a Timeline-layout preference).

**Do not change features, data flow, props, links, form fields, or component APIs.** This is a styling/interaction pass. Every existing field, `pushState` branch, link, and `isAdmin`/`isLoggedIn` gate must be preserved.

## About the Design Files
The bundled file **`The Hoecks - Archive.dc.html`** is a **design reference built in HTML** — an interactive prototype showing the intended look and behavior. It is **not production code to copy directly**, and it is authored in a custom "Design Component" wrapper (`<x-dc>` + a `Component` logic class) that is **not** part of your stack.

`ios-frame.jsx` is **mock device chrome only** (status bar, bezel, home indicator) used to preview the screens on a fake phone. **Ignore it for implementation** — your app already renders inside a real device.

Your task: **recreate these designs in the existing codebase** — Next.js 15 (App Router) + React 19, Tailwind CSS v4, `Source Sans 3` already wired via `next/font` — using its established patterns. Add **no new dependencies** and **no component/UI libraries**; plain Tailwind + inline SVG icons.

## Fidelity
**High-fidelity.** Exact colors, typography, spacing, radii, shadows, and motion are specified below — recreate pixel-faithfully. Mobile-first; beautiful at 380px and on desktop. Honor iOS safe areas (`env(safe-area-inset-*)`), standalone PWA mode, touch targets ≥ 44px, no layout shift.

---

## New Dependency: Add the brand serif
The redesign introduces **Source Serif 4** as the brand/display voice (wordmark, "The Latest", page titles, the year numerals in the timeline). Source Sans 3 remains for all UI/body/controls. Wire Source Serif 4 via `next/font/google` alongside the existing Source Sans 3 and expose it as a CSS variable (e.g. `--font-serif`).

```ts
// app/fonts.ts (or wherever Source Sans 3 is wired)
import { Source_Sans_3, Source_Serif_4 } from 'next/font/google';
export const sans  = Source_Sans_3({ subsets: ['latin'], variable: '--font-sans', weight: ['300','400','500','600','700'] });
export const serif = Source_Serif_4({ subsets: ['latin'], variable: '--font-serif', weight: ['400','500','600','700'] });
```
Apply both variables on `<html>`/`<body>`. In Tailwind v4, register `--font-serif` so `font-serif` utility maps to it.

---

## Design Tokens

### Color — warm near-black surfaces
| Token | Hex | Use |
|---|---|---|
| `canvas` | `#1a1918` | App background |
| `panel` | `#211e1a` | Raised keepsake cards (memory card) |
| `panel-2` | `#1c1a18` | Secondary cards (admin, favorites, featured) |
| `panel-3` | `#201d19` / `#201d1a` | "The Latest" masthead, upload action bar |
| `inset` | `#151312` | Inputs, selects, segmented-control track |
| `hover` | `#211e1b` / `#252118` | Row/button hover fills |
| `border` | `#2b2722` | Default hairline border |
| `border-soft` | `#262320` | Panel borders (alt) |
| `border-faint` | `#232020` | Inner dividers, timeline row separators |
| `border-input` | `#322e29` | Input/select borders |
| `border-btn` | `#3a352d` | Secondary button borders |

### Color — gold (the signature accent, from the app icon)
| Token | Hex | Use |
|---|---|---|
| `gold` | `#c2a467` | Monogram, FAB, primary buttons, switch ON, focus accents |
| `gold-bright` | `#d2b577` | Gold hover |
| `gold-mid` | `#cda86a` | Memory/clock icons |
| `gold-link` | `#cfae6f` | Gold text links (Upload Photo, "Send today's memory") |
| `gold-dim` | `#8a774d` | Small-caps section labels, chevrons, hairline accents |
| `gold-sub` | `#9a8758` | "The Latest" subtitle |
| gold tint bg | `rgba(194,164,103,0.12–0.16)` | Icon badges, gold-tinted surfaces |
| gold tint border | `rgba(194,164,103,0.22–0.42)` | Gold keylines (monogram, drop zone, badges) |
| gold focus ring | border `rgba(194,164,103,0.6)` + shadow `0 0 0 3px rgba(194,164,103,0.16)` | Input/select/search focus |

### Color — text
| Token | Hex |
|---|---|
| text-hi (headings) | `#efeae1` / `#f0ebe2` |
| text (body) | `#c9c4ba` |
| text month | `#c2bdb3` |
| text muted | `#a39e93` |
| text muted-2 | `#8a8378` / `#8a857c` |
| text muted-3 | `#7d7468` |
| text faint | `#6c675d` |
| text fainter | `#56524a` |
| build tag | `#4f4b43` |

### Color — semantic
| Token | Hex | Use |
|---|---|---|
| heart | `#d9655f` | Favorites heart |
| success | `#7faf74` (icon) / `#8fbf83` (text) | "Notifications are on", "Settings saved" |
| success bg | `rgba(127,175,116,0.10)` border `rgba(127,175,116,0.24–0.26)` | Success rows/banner |
| danger (hover) | `#d98a87` border `rgba(217,101,95,0.35)` | "Turn off" / "Log out" hover |

### Typography
- **Serif (`Source Serif 4`)**: wordmark 22–23/600; "The Latest" 22/600; page titles (`Settings`, `Upload`) 32/600, letter-spacing −0.01em; year numerals 27/500 (classic) and 30/600 (rail selected); card titles ("Daily memory notifications", "Timeline layout", "Your album is waiting") 18–19/600; numbered-step digits 14/600.
- **Sans (`Source Sans 3`)**: body 15–16/400–500; buttons 15–16/600–700; month rows 15/500; small-caps section labels **11/700, letter-spacing 0.2em, uppercase**, color `#8a774d`; field labels 12/700, 0.1em, uppercase, `#8a8378`.
- **Mono (`ui-monospace`)**: build tag 10.5px, letter-spacing 0.14em, `#4f4b43`.
- Use `font-variant-numeric: tabular-nums` on all year/count numerals.

### Radius
Cards 18–22px · inputs/selects/controls 11–14px · icon badges 11–16px · pills/chips 999px · small rows/buttons 6–9px.

### Shadow / Elevation
- Panel: `0 8px 26px rgba(0,0,0,0.32)` + inset top highlight `inset 0 1px 0 rgba(255,255,255,0.04)`
- Masthead ("The Latest"): `0 10px 26px rgba(0,0,0,0.32)`
- Upload action bar: `0 14px 32px rgba(0,0,0,0.32)` + `inset 0 1px 0 rgba(255,255,255,0.05)`
- Gold FAB / primary buttons: `0 10px 28px rgba(122,96,42,0.5)` (FAB) / `0 10px 24px rgba(122,96,42,0.32–0.35)` (buttons) + inset `0 1px 0 rgba(255,255,255,0.35)`

### Motion
- Expand/collapse + chevron rotate: `0.22–0.28s cubic-bezier(0.4,0,0.2,1)` (animate `max-height` + `transform: rotate(180deg)`).
- Toggle/switch + segmented control: `0.18–0.24s ease`.
- Keep it restrained. No bounce.

### Texture (optional, subtle)
A faint paper grain overlays each screen: an inline SVG `feTurbulence` (`baseFrequency 0.85`, `numOctaves 2`) at **opacity 0.045**, `mix-blend-mode: soft-light`, `pointer-events:none`, `position:absolute; inset:0`. Nice-to-have; safe to omit if it complicates the build.

---

## Screens / Components

### 1. `src/components/ArchiveMenu.tsx` — Navigation
Slide-out drawer on mobile (opened via FAB); persistent **280px left sidebar ≥1024px**. Redesign the shared `sidebarContent`. **Keep:** FAB + secondary upload-FAB behavior, backdrop, desktop hover/tuck logic, all links, and `isAdmin`/`isLoggedIn` gating.

Top-to-bottom order of `sidebarContent`:

1. **Brand header** — an embossed gold monogram **H** (serif, 28/600, color `#c2a467`) in a 48×48 rounded square (`#151312` bg, `1px rgba(194,164,103,0.42)` keyline, inset highlights), beside the serif wordmark **"The Hoecks"** (23/600, `#efeae1`) over a small-caps label **"FAMILY ARCHIVE"** (10.5/700, 0.22em, `#8a774d`). *(This replaces the old orphaned build-version string in the header; the build string moves to the admin footer — see #6.)*
2. **Search** — 50px tall, `#151312` bg, `1px #322e29` border, radius 13, left magnifier icon (`#857f73`), placeholder "Search the album…" (`#6c675d`). Focus = gold ring.
3. **ALBUMS** label, then:
   - **The Latest** (masthead) — prominent row: `#201d19` bg, gold keyline `1px rgba(194,164,103,0.26)`, shadow. A gold-tinted 44px badge with a gold star/sparkle icon; serif "The Latest" (22/600, `#f1ece3`) over small-caps "NEWEST MOMENTS FIRST" (`#9a8758`); trailing gold chevron. This is the hero entry — clearly the most prominent.
   - **Favorites** — `#1c1a18` bg, `1px #2b2722`; heart badge (`#d9655f` heart on `rgba(217,101,95,0.10)`); label (17/600); count "24" (mono-ish, `#6c675d`); muted chevron.
4. **FEATURED** label, then a 2-up row of album cards (rounded 13, `#1c1a18`, `1px #2b2722`): a 92px striped image placeholder (real thumbnails in production) + serif name (15/600) + "N PHOTOS" (11/600, 0.06em, `#6c675d`). This section is **optional** per data.
5. **TIMELINE** — header row: "TIMELINE" small-caps label + a hairline rule + a faint "2012 — 2026" range (`#56524a`). Below it, the year index — **see "Timeline layouts" below** (this is the heart of the app).
6. **Admin footer** (gated by `isAdmin`) — top hairline, a gold shield + "ADMIN" small-caps label, then rows **Upload Photo** (gold text+icon, `#cfae6f`), **Bulk Import**, **Settings** (neutral `#c9c4ba`), a hairline, then **Log out** (`#938b82`, red-tinted hover). At the very bottom, the **mono build string** `BUILD 8c0017b` (10.5px, `#4f4b43`). Each row ≥44px.

**FAB cluster** (mobile, bottom-right, sticky to the drawer's bottom): a 60px **gold** primary FAB (`#c2a467`, dark `#1a1715` "+" glyph, gold glow shadow). When the menu is active it fans out **two 46px secondary bubbles arranged in an arc around** the primary (dark `#211e1b`, `1px #322e29`, gold icons): **Upload** (up-arrow) directly above the primary; **Settings** (gear cog) offset to the lower-left. No text labels.

#### Timeline layouts (two, user-switchable — see Settings #2)
The year index renders in one of two layouts based on a persisted preference (`timelineStyle`: `'classic'` | `'rail'`, default **classic**):

- **Classic list** (default): a vertical list of years **2026 → 2012**, each row = serif year numeral (27/500, `#d8d3c8`, min-width 76px) + a hairline leader rule + a gold-dim chevron. Tapping a year expands its **months** (animated `max-height`): full month names (15/500, `#c2bdb3`) as tappable rows, indented, **no per-month counts and no vertical guide line**. No per-year totals. Row min-height 58px (year), 40px (month).
- **Year rail**: a two-column layout — left column shows the **selected year** (serif 30/600, gold `#cfae6f`) above its month rows; right column is a fixed ~54px **edge index** listing **all 15 years** as compact tappable buttons (12/600, tabular), the selected one filled gold (`#c2a467` bg, `#1a1715` text), others `#7d7468` on transparent. Tapping a rail year selects it — any year is one tap away regardless of history length.

Desktop 280px rail mirrors the same content (condensed; classic list is fine there).

### 2. `src/components/SettingsClient.tsx` — Settings page
Title "Settings" (serif 32/600) with a gold "Done" link. A **status message banner** (success styling shown: green check + "Settings saved"). Two sections with small-caps gold labels:

**YOUR DEVICE**
- **Daily memory notifications** card (the emotional heart) — `#211e1a` panel, **gold keyline** `1px rgba(194,164,103,0.24)`, shadow. Gold clock/sun badge; serif title; warm copy: "A gentle teaser each morning — a memory from years past, on this very day." The card **body changes by `pushState`** — preserve all branches:
  - `loading` → spinner (gold top, `hk-spin` 0.8s) + "Checking your notification status…"
  - `needs-install` → serif "Add to your Home Screen first" + 3 **numbered** iOS steps (gold serif digits in gold-keyline circles): 1 Tap the **Share** button (with share icon), 2 Choose **Add to Home Screen**, 3 Open it from your Home Screen.
  - `unsupported` → info icon + fallback copy ("This browser can't do daily memory notifications. Open The Hoecks from your Home Screen…").
  - `off` → gold badge + serif "A memory every morning" + copy + **primary gold button** "Turn on daily memories".
  - `on` → green check row "Notifications are on for this device" + two secondary buttons "Send me a test" / "Turn off" (red-tinted hover).
- **Timeline layout** card (NEW) — `#1c1a18` panel; gold list-icon badge; serif "Timeline layout"; copy "How the years index appears in the menu. The year rail keeps any year a single tap away as the archive grows."; a **segmented control** (track `#151312`, `1px #2b2722`, radius 13, 5px padding) with two ≥44px options **Classic list** / **Year rail**. Active option = gold tint bg `rgba(194,164,103,0.15)` + gold text `#cfae6f`; inactive = transparent + `#8a8378`. Selecting one updates the menu timeline and persists (see State).

**ADMIN** (gated)
- **Send daily memory notifications** row: label + "N devices subscribed" sub + a proper **toggle switch** (52×32 track; ON = gold `#c2a467`, OFF = `#3a352d`; 26px cream knob `#f3eee4`; knob slides `left 3px → 23px`; 0.24s).
- 2-col grid: **Send hour** select (24 options) + **Timezone** select — both **custom-styled** (`appearance:none`, `#151312` bg, `1px #322e29`, radius 12, 48px tall, custom chevron, gold focus ring) to kill the OS look.
- **Send today's memory now** — gold-outline secondary button (`rgba(194,164,103,0.08)` bg, `1px rgba(194,164,103,0.4)`, `#cfae6f` text).
- Hairline. Then text fields (each: uppercase field label + 48px input, `#151312`/`#322e29`/radius 12, gold focus): **Site title**, **Site description**, **Banner message**, **iMessage recipients**, **Change family password** (type=password).
- **Save settings** — full-width **primary gold button** (`#c2a467`, dark text `#1a1715`, 700, radius 14, gold glow).

### 3. `src/app/admin/upload/page.tsx` — Upload, EMPTY state only
**Only redesign the empty state.** Leave the drag-reorder grid, crop modal, and upload flow untouched.
- Header (top, centered): serif "Upload" (32/600) + "Add new moments to the family archive." (`#8a8378`).
- **Empty-state visual** (fills the upper area): a fanned **stack of 3 photo-placeholder cards** (striped, rounded 13, rotated −9°/+9°/0°, the front one gold-keylined with a photo glyph), then serif "Your album is waiting" (21/600) + copy "Add photos or videos and they'll quietly file themselves into the right year by date." (`#8a8378`, max-width ~280px).
- **Action footer — STICKY to the bottom of the screen** (`position: sticky; bottom: 0`, sitting in the thumb zone above the home indicator; the screen must be full-height so it pins). Contains, in order:
  1. **Tap to choose photos or videos** — a tactile, full-width tappable bar: `#201d1a` bg, an **8px-inset dashed gold keyline** (`1.5px dashed rgba(194,164,103,0.42)`, radius 13), shadow. Left: 56px gold up-arrow badge. Middle: serif "Tap to choose photos or videos" (18/600) + "or drag them straight in · JPG, PNG, MOV, MP4" (13, `#7d7468`). Right: gold chevron. (This is the file picker / drop zone — wire to the existing input.)
  2. **Back** — a compact, **left-aligned** link (15/500, `#938b82`, left chevron). This is the very bottom row.

---

## Interactions & Behavior
- **Drawer**: FAB toggles the slide-out + backdrop on mobile; persistent sidebar ≥1024px with existing hover/tuck logic. Secondary FABs fan out around the primary as described.
- **Timeline year expand/collapse** (classic): animate `max-height` + chevron rotate, 0.22–0.28s. Multiple years may be open; default 2026 open.
- **Timeline rail**: tapping a rail year sets the selected year and swaps the left column's months. Default selected = newest (2026).
- **Timeline layout switch**: the Settings segmented control sets `timelineStyle`; the menu reflects it immediately and the choice persists.
- **Settings device card**: render strictly by `pushState`; preserve every branch and the top status-message banner.
- **Admin toggle / selects / inputs**: controlled, with the styled treatments above; gold focus ring on all text inputs/selects/search.
- **Hover/active/focus**: every row/button has a defined hover (subtle warm fill `#211e1b`, or gold/red tints per role); inputs show the gold focus ring; touch targets ≥44px.

## State Management
- `ArchiveMenu`: existing drawer-open, `isAdmin`, `isLoggedIn`; per-year `expanded` set; rail `selectedYear`.
- `SettingsClient`: existing `pushState` + status message; admin booleans (send-notifications), select values (hour, timezone), all text fields, password.
- **`timelineStyle`** (NEW): `'classic' | 'rail'`, default `'classic'`. Persist to `localStorage` under key **`hoecks_timeline`**; read on mount; write on change. It is read by `ArchiveMenu` and written by `SettingsClient` — lift it to shared state (context, store, or server-persisted user pref) so the Settings control drives the menu. (The prototype uses `localStorage` + shared component state.)

## Assets
- **App icon / monogram**: a serif **H** in gold `#c2a467` on `#1a1918` (matches `public` app icon, e.g. `icon-192.png`). The in-app monogram is rendered as a styled `<span>`, not an image.
- **Featured & upload visuals**: striped **placeholders** in the prototype — replace with real album thumbnails / the user's photos.
- **Icons**: all inline SVG (search, heart, star, chevrons, plus, upload, gear cog, bulk-import, settings, logout, shield, clock, check, info, share, list). Stroke ~1.6–2px. Recreate as inline SVG components; do not add an icon library.

## Files
- `The Hoecks - Archive.dc.html` — the full interactive design reference (all screens + both timeline layouts + the Settings toggle). Open in a browser to see behavior. Authored in a custom Design-Component format — read it for exact markup/values, but reimplement in React/Tailwind.
- `ios-frame.jsx` — mock phone chrome used only to frame the prototype. **Ignore for implementation.**

> The bundled HTML is a **design reference**, not shippable code. Recreate it in the existing Next.js 15 / React 19 / Tailwind v4 app using its patterns, `next/font` for Source Sans 3 + Source Serif 4, inline SVG icons, and **no new dependencies**. Preserve all existing behavior, props, fields, `pushState` branches, links, and admin/auth gating.
